/*
Name:Amrit Gautam
ID:1002159618
Compilation Command: gcc AssignmentBinarySearch.c -o binarySearch
Using Command Prompt to run the program
*/

#include <stdio.h>
#include <stdlib.h>

// Function to perform binary search and find the element with a given rank
int customBinary_Search(int *sequenceX, int *sequenceY, int lengthX, int lengthY, int targetRank)
{
    int low = 0;
    int high = lengthX;

    while (low <= high)
    {
        int mid = (low + high) / 2;
        int j = targetRank - mid;

        // Checking if the corresponding element is found
        if ((j == 0 || (j > 0 && sequenceY[j] < sequenceX[mid])) && (j == lengthY || sequenceX[mid] <= sequenceY[j]))
        {
            // For debugging output when the corresponding element is found based on mid and j
            printf("low=%d high=%d mid=%d j=%d\n", low, high, mid, j);
            return sequenceX[mid];
        }
        else if (j < 0)
        {
            // Adjusting the search range for the first sequence
            high = mid - 1;
        }
        else
        {
            // Adjusting the search range for the first sequence
            low = mid + 1;
        }
    }

    // If the element is not found
    return -1;
}

int main()
{
    // Read the lengths of sequences and the number of ranks from the standard input
    int lengthX, lengthY, numRanks;
    scanf("%d %d %d", &lengthX, &lengthY, &numRanks);

    // Allocate memory for sequenceX and sequenceY dynamically with additional space for sentinel values
    int *sequenceX = (int *)malloc((lengthX + 2) * sizeof(int));
    int *sequenceY = (int *)malloc((lengthY + 2) * sizeof(int));

    // Read sequenceX elements from the standard input
    for (int i = 1; i <= lengthX; i++)
    {
        scanf("%d", &sequenceX[i]);
    }

    // Read sequenceY elements from the standard input
    for (int j = 1; j <= lengthY; j++)
    {
        scanf("%d", &sequenceY[j]);
    }

    // Perform binary searches for each rank
    for (int r = 1; r <= numRanks; r++)
    {
        int targetRank;
        scanf("%d", &targetRank);

        // Call the customBinarySearch function to find the element with the given rank
        int result = customBinary_Search(sequenceX, sequenceY, lengthX, lengthY, targetRank);

        // Output the result
        printf("Rank %d: Element %d\n", targetRank, result);
    }

    // Free the allocated memory
    free(sequenceX);
    free(sequenceY);

    return 0;
}
